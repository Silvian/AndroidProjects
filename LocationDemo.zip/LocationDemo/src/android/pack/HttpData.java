package android.pack;

import java.util.Hashtable;
public class HttpData {
      public String content;
      @SuppressWarnings("unchecked")
	public Hashtable cookies = new Hashtable();
      @SuppressWarnings("unchecked")
	public Hashtable headers = new Hashtable();
}
